% This file illustrates some binary image analysis operations using Matlab.
%
% CS 484, Spring 2007
% Author: Selim Aksoy

% Read and plot a microscopic tissue image with three bands.
x = imread( 'prostate1.png' );
%x = imread( 'prostate2.png' );     % Uncomment this line for the second example.
figure; imagesc( x ); axis image;
title( 'Prostate image' ); pause;

% Plot the green band.
figure; imagesc( x(:,:,2) ); colormap( gray ); axis image;
title( 'Green band of the prostate image' ); pause;

% Threshold the green band and obtain a binary image.
y = x(:,:,2) < 130;
%y = x(:,:,2) < 90;                 % Uncomment this line for the second example.
figure; imagesc( y ); colormap( gray ); axis image;
title( 'Thresholding green band' ); pause;

% Find the boundaries of binary 1 regions and overlay on the rgb image
% using the cyan color (set red to 0, green and blue to 255).
b = bwperim( y );
z = x;
temp = z(:,:,1); temp( b ) = 0; z(:,:,1) = temp;
temp = z(:,:,2); temp( b ) = 255; z(:,:,2) = temp;
temp = z(:,:,3); temp( b ) = 255; z(:,:,3) = temp;
figure; imagesc( z ); axis image;
title( 'Boundaries overlayed on rgb image' ); pause;

% Erode the binary image using a disk structuring element with radius 5 to
% get rid of structures smaller than this size.
s = strel( 'disk', 5 );
y2 = imerode( y, s );
figure; imagesc( y2 ); colormap( gray ); axis image;
title( 'Eroding by disk(5)' ); pause;

% Perform conditional dilation to recover structures larger than the disk.
y3 = imreconstruct( y2, y, 4 );
figure; imagesc( y3 ); colormap( gray ); axis image;
title( 'Conditional dilation' ); pause;

% Overlay the boundaries of the recovered regions on the rgb image.
b = bwperim( y3 );
z = x;
temp = z(:,:,1); temp( b ) = 0; z(:,:,1) = temp;
temp = z(:,:,2); temp( b ) = 255; z(:,:,2) = temp;
temp = z(:,:,3); temp( b ) = 255; z(:,:,3) = temp;
figure; imagesc( z ); axis image;
title( 'Boundaries overlayed on rgb image' ); pause;

% Find connected components (using 4-connectivity) and plot by coloring
% each component using the "jet" colormap.
c = bwlabel( y3, 4 );
n = max( c(:) );
c2 = label2rgb( c, jet( n ), [ 0 0 0 ] );
figure; imagesc( c2 ); axis image;
title( 'Connected components' );
fprintf( 'There are %d connected components in the image.\n', n );
